from .AbsMethod import AbsMethod
from .heMethod import HeImage
from .mathMethod import MathImage

